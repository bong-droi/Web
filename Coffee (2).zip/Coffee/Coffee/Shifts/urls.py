from django.urls import path
from . import views

urlpatterns = [
    path('', views.shift_list, name='shift_list'),
    path('create/', views.shift_create, name='shift_create'),
    path('update/<int:pk>/', views.shift_update, name='shift_update'),
    path('delete/<int:pk>/', views.shift_delete, name='shift_delete'),
    path('register/', views.shift_register, name='shift_register'),
    path('my/', views.my_shifts, name='my_shifts'),
]
