from django import forms
from .models import Shift, ShiftRegistration

class ShiftForm(forms.ModelForm):
    class Meta:
        model = Shift
        fields = '__all__'

class ShiftRegistrationForm(forms.ModelForm):
    class Meta:
        model = ShiftRegistration
        fields = ['shift', 'date']
