from django.db import models
from django.conf import settings

class Shift(models.Model):
    name = models.CharField(max_length=50)              # Ví dụ: Ca sáng
    start_time = models.TimeField()
    end_time = models.TimeField()

    def __str__(self):
        return f"{self.name} ({self.start_time} - {self.end_time})"

class ShiftRegistration(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    shift = models.ForeignKey(Shift, on_delete=models.CASCADE)
    date = models.DateField()

    class Meta:
        unique_together = ('user', 'shift', 'date')     # 1 nhân viên không đăng ký 2 lần cho cùng ca
