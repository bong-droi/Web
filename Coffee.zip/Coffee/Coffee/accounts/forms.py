from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import User
# accounts/forms.py
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import SetPasswordForm
User = get_user_model()

class UserEditForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ["username", "first_name", "last_name", "email", "is_active"]
        widgets = {
            "username": forms.TextInput(attrs={"class":"input__control"}),
            "first_name": forms.TextInput(attrs={"class":"input__control"}),
            "last_name": forms.TextInput(attrs={"class":"input__control"}),
            "email": forms.EmailInput(attrs={"class":"input__control"}),
        }

class RoleForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ["role"]

class QuickCreateStaffForm(forms.Form):
    username = forms.CharField(max_length=150)
    password = forms.CharField(widget=forms.PasswordInput)
    first_name = forms.CharField(max_length=30, required=False)
    last_name = forms.CharField(max_length=150, required=False)
    email = forms.EmailField(required=False)

class RegisterForm(UserCreationForm):
    class Meta:
        model = User
        fields = ["username", "email"]  # thêm các trường bạn muốn

    def save(self, commit=True):
        user = super().save(commit=False)
        user.role = "customer"   # mặc định khách hàng
        if commit:
            user.save()
        return user
