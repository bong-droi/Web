from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import Order, OrderItem
from .forms import OrderItemForm

@login_required
def order_list(request):
    orders = Order.objects.all().order_by('-created_at')
    return render(request, "orders/order_list.html", {"orders": orders})

@login_required
def order_create(request):
    if request.method == "POST":
        order = Order.objects.create(staff=request.user)
        return redirect("order_detail", pk=order.pk)
    return render(request, "orders/order_create.html")

@login_required
def order_detail(request, pk):
    order = get_object_or_404(Order, pk=pk)
    items = order.items.all()

    if request.method == "POST":
        form = OrderItemForm(request.POST)
        if form.is_valid():
            item = form.save(commit=False)
            item.order = order
            item.save()
            return redirect("order_detail", pk=order.pk)
    else:
        form = OrderItemForm()

    return render(request, "orders/order_detail.html", {
        "order": order,
        "items": items,
        "form": form
    })

@login_required
def order_delete(request, pk):
    order = get_object_or_404(Order, pk=pk)
    order.delete()
    return redirect("order_list")
