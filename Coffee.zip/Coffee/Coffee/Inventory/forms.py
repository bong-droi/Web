from django import forms
from .models import Supply, Purchase

class SupplyForm(forms.ModelForm):
    class Meta:
        model = Supply
        fields = ['name', 'unit', 'quantity']

class PurchaseForm(forms.ModelForm):
    class Meta:
        model = Purchase
        fields = ['supply', 'quantity', 'cost']
