from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import Shift, ShiftRegistration
from .forms import ShiftForm, ShiftRegistrationForm

# --- Chủ quán quản lý ca ---
@login_required
def shift_list(request):
    shifts = Shift.objects.all()
    return render(request, "shifts/shift_list.html", {"shifts": shifts})

@login_required
def shift_create(request):
    if request.user.role != "owner":
        return redirect("shift_list")
    if request.method == "POST":
        form = ShiftForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("shift_list")
    else:
        form = ShiftForm()
    return render(request, "shifts/shift_form.html", {"form": form})

@login_required
def shift_update(request, pk):
    if request.user.role != "owner":
        return redirect("shift_list")
    shift = get_object_or_404(Shift, pk=pk)
    if request.method == "POST":
        form = ShiftForm(request.POST, instance=shift)
        if form.is_valid():
            form.save()
            return redirect("shift_list")
    else:
        form = ShiftForm(instance=shift)
    return render(request, "shifts/shift_form.html", {"form": form})

@login_required
def shift_delete(request, pk):
    if request.user.role != "owner":
        return redirect("shift_list")
    shift = get_object_or_404(Shift, pk=pk)
    shift.delete()
    return redirect("shift_list")

# --- Nhân viên đăng ký ca ---
@login_required
def shift_register(request):
    if request.method == "POST":
        form = ShiftRegistrationForm(request.POST)
        if form.is_valid():
            registration = form.save(commit=False)
            registration.user = request.user
            registration.save()
            return redirect("my_shifts")
    else:
        form = ShiftRegistrationForm()
    return render(request, "shifts/shift_register.html", {"form": form})

@login_required
def my_shifts(request):
    my_shifts = ShiftRegistration.objects.filter(user=request.user)
    return render(request, "shifts/my_shifts.html", {"my_shifts": my_shifts})
